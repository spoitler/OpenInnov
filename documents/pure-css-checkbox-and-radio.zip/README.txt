A Pen created at CodePen.io. You can find this one at https://codepen.io/raubaca/pen/PZzWRN.

 Checkbox and radio inputs styled using ::before and ::after pseudoelements